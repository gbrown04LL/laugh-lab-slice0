import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { STUB_USER_ID } from "@/lib/types";
import type { ReportResponse, FinalOutput, ErrorObject } from "@/lib/types";
import { 
  errorResponse, 
  validationError, 
  notFoundError, 
  internalError, 
  generateRequestId 
} from "@/lib/api-errors";
import logger from "@/lib/logger";

// Required for Prisma on Vercel serverless
export const runtime = "nodejs";

interface RouteParams {
  params: Promise<{
    run_id: string;
  }>;
}

/**
 * GET /api/reports/[run_id]
 * 
 * Retrieve the immutable analysis report for a completed job run.
 * Returns Truth Contract compliant output with schema_version 1.0.0
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse<ReportResponse | { errors: ErrorObject[] }>> {
  const { run_id } = await params;
  const request_id = generateRequestId();
  const endTimer = logger.startTimer("GET /api/reports/[run_id]", { run_id, request_id });

  try {
    // Validate UUID format
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(run_id)) {
      logger.warn("Invalid run_id format", { run_id, user_id: STUB_USER_ID, request_id });
      return errorResponse(400, [
        validationError("Invalid run_id format", request_id),
      ]);
    }

    // Fetch report with owner check
    const report = await prisma.analysisReport.findUnique({
      where: { id: run_id },
      select: {
        id: true,
        job_id: true,
        user_id: true,
        schema_version: true,
        output: true,
        created_at: true,
      },
    });

    if (!report) {
      logger.warn("Report not found", { run_id, user_id: STUB_USER_ID, request_id });
      return errorResponse(404, [
        notFoundError("Report", request_id),
      ]);
    }

    // Owner check
    if (report.user_id !== STUB_USER_ID) {
      logger.warn("Report ownership mismatch", { 
        run_id, 
        user_id: STUB_USER_ID,
        request_id,
      });
      // Don't reveal ownership info
      return errorResponse(404, [
        notFoundError("Report", request_id),
      ]);
    }

    logger.info("Report retrieved", { 
      run_id: report.id, 
      job_id: report.job_id,
      user_id: report.user_id,
      request_id,
      schema_version: report.schema_version,
    });

    endTimer();

    return NextResponse.json({
      id: report.id,
      job_id: report.job_id,
      schema_version: report.schema_version,
      output: report.output as FinalOutput,
      created_at: report.created_at.toISOString(),
    });

  } catch (error) {
    logger.error("Failed to retrieve report", { 
      run_id,
      user_id: STUB_USER_ID,
      request_id,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    
    return errorResponse(500, [
      internalError("Internal server error", request_id),
    ]);
  }
}
